CREATE TABLE item (
    id   INT         NOT NULL PRIMARY KEY,
    name VARCHAR(20) NOT NULL
);

INSERT INTO item VALUES (1, '富士');
INSERT INTO item VALUES (2, '鷹');
INSERT INTO item VALUES (3, 'なすび');
